package sample06;

public interface Salary {
	
	public void execute();

}
