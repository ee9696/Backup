package guestbook.dao;

import java.io.IOException;
import java.io.Reader;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GuestbookDAO {
	
	private static GuestbookDAO instance;
	private SqlSessionFactory sqlSessionFactory;
	
	public static GuestbookDAO getInstance() {
		if(instance == null) {
			synchronized (GuestbookDAO.class) {
				instance = new GuestbookDAO();//생성
			}
		}
		
		return instance;
	}
	public GuestbookDAO() {
		try {
			Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void guestbookWrite(Map<String, String> map) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.insert("guestbookSQL.guestbookWrite", map);
		sqlSession.commit();
		sqlSession.close();
		
	}
}