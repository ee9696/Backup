$(function(){
	$ajax({
		url:'MQBProject/guestbook/guestbookList.do',
		type:'post',
		data:'pg='+$('#pg').val(),
		dataType:'json',
		success:function(data){
			console.log(JSON.stringify(data));
			
			$.each(data.list, function(index, items){
				$('tr/>')
					.append($('<td/>',{
						width:'100',
						align:'center',
						value:'작성자'
					})).append($('<td/>',{
						width:'100',
						align:'center',
						text:items.name
					})).append($('<tr/>',{
						
					})).append($('<td/>',{
						text:'이메일',
					})).append($('<td/>',{
						text:items.email,
						colspan:'3',
						align:'center'
					})).append($('<tr/>',{
						
					}).append($('<td/>',{
						text:'제목'
					}))).append($('<td/>',{
						colspan:'4'
					})).append($('<pre/>',{
						text:items.content
					})).appndTo($('#guestbookTable'));
						
			});
		},
		error:function(err){
			console.log(err);
		}
	});
});