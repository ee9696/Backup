create table invenmember(
name varchar2(30) not null,
id varchar2(30) primary key,
pwd varchar2(30) not null,
email1 varchar2(20),
email2 varchar2(20));

select * from invenmember;