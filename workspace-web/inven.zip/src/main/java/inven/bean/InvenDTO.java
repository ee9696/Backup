package inven.bean;

import lombok.Data;

@Data
public class InvenDTO {
	private String name;
	private String id;
	private String pwd;
	private String email1;
	private String email2;
}
